function inline(){
    const mystyle={
        color:'white', 
        marginleft: 600,
        fontSize: '4rem',
        margin: '0',
        // backgroundColor:'Black',
        // padding:'10px'
     }
     return (
        <>
            <h1 style={mystyle}>YOU CAN</h1>
            <h1 style={mystyle}>  HIRE FREELANCER </h1>   
                
           <h1 style={mystyle}> HERE </h1>
            <h3 style={{color:'white'}}>It is a long established fact that a reader will be distracted by a readable content of a page</h3>
        </>
         
     )
 }
 export default inline;
