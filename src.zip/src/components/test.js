function Test(){
    const mystyle={
       color:'red', 
       backgroundColor:'Black',
       padding:'10px'
    }
    return (
        <h1 style={mystyle}>Css styles are applied</h1>
    )
}
export default Test;