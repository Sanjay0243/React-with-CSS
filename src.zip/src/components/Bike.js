import Car from './Car';
function Bike(){
    return(
        <>
        <h2>This is the bike function</h2>
        <Car />
        </>
       
    )
}
export default Bike;