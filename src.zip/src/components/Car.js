function Car(){
    return (
        <>
        <h2>This is the car function inside component folder</h2>
        </>
    )
}

export default Car;