// import logo from './logo.svg';
import './App.css';
// import user from 'react';
// import UserProfile from './Userprofile'; 
function App() {
  return (
    <h1>Welcome to react</h1>
  );
}

// App.js
// import React from 'react';
// import UserProfile from './Userprofile'; // Adjust the path if needed

// const App = () => {
//   return (
//     <div className="App">
//       <h1>User Profiles</h1>
//       {/* Example user profile #1 */}
//       <UserProfile 
//         name="John Doe" 
//         age={30} 
//         location="New York" 
//         isActive={true} 
//       />
      
//       {/* Example user profile #2 (no location provided) */}
//       <UserProfile 
//         name="Jane Smith" 
//         age={25} 
//         isActive={false} 
//       />

//       {/* Example user profile #3 (inactive user) */}
//       <UserProfile 
//         name="Alice Johnson" 
//         age={22} 
//         location="California" 
//         isActive={false} 
//       />
//     </div>
//   );
// }

export default App;
